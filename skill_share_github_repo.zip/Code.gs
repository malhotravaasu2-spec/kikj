/**
 * ============================================================================
 * Skill Share: Google Sheets Backend Server (Google Apps Script)
 * ============================================================================
 * 
 * INSTRUCTIONS TO DEPLOY:
 * 1. Open Google Sheets (https://sheets.new)
 * 2. Click "Extensions" > "Apps Script" in the top menu.
 * 3. Delete any default code in Code.gs and paste this entire file.
 * 4. Click the blue "Deploy" button (top right) > "New deployment".
 * 5. Select type: "Web app" (click the gear icon next to "Select type").
 * 6. Set the following options:
 *    - Description: "Skill Share Backend API"
 *    - Execute as: "Me" (your email)
 *    - Who has access: "Anyone" (crucial for web access from your site)
 * 7. Click "Deploy", authorize permissions, and COPY the "Web App URL".
 * 8. Paste that Web App URL into your `app.js` under CONFIG.GOOGLE_SHEET_WEB_APP_URL.
 * ============================================================================
 */

function setupSpreadsheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // Tab 1: Skilled Neighbors
  var skillsSheet = ss.getSheetByName('Artisans_Skills');
  if (!skillsSheet) {
    skillsSheet = ss.insertSheet('Artisans_Skills');
    skillsSheet.appendRow([
      'Artisan ID',
      'Registration Date',
      'Full Name',
      'Trade / Skill',
      'Experience (Yrs)',
      'Phone',
      'Rate',
      'Neighborhood Address',
      'Bio / Specialization',
      'Longitude',
      'Latitude'
    ]);
    formatHeaderRow(skillsSheet);
  }

  // Tab 2: Client Ratings
  var ratingsSheet = ss.getSheetByName('Client_Ratings');
  if (!ratingsSheet) {
    ratingsSheet = ss.insertSheet('Client_Ratings');
    ratingsSheet.appendRow([
      'Rating Timestamp',
      'Artisan ID',
      'Artisan Name',
      'Client Name',
      'Service Performed',
      'Stars (1-5)',
      'Feedback & Review'
    ]);
    formatHeaderRow(ratingsSheet);
  }

  // Tab 3: Tool Reservations
  var toolsSheet = ss.getSheetByName('Tool_Reservations');
  if (!toolsSheet) {
    toolsSheet = ss.insertSheet('Tool_Reservations');
    toolsSheet.appendRow([
      'Reservation Timestamp',
      'Tool ID',
      'Tool Name',
      'Status'
    ]);
    formatHeaderRow(toolsSheet);
  }
}

function formatHeaderRow(sheet) {
  var range = sheet.getRange(1, 1, 1, sheet.getLastColumn());
  range.setFontWeight('bold');
  range.setBackground('#2E5A44');
  range.setFontColor('#FFFFFF');
  sheet.setFrozenRows(1);
}

/**
 * Handle incoming POST requests from the Skill Share website
 */
function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    setupSpreadsheet();
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    
    // Parse the payload
    var payload;
    if (e.postData && e.postData.contents) {
      payload = JSON.parse(e.postData.contents);
    } else {
      payload = e.parameter;
    }

    var action = payload.action;
    var data = payload.data || {};

    if (action === 'registerArtisan') {
      var sheet = ss.getSheetByName('Artisans_Skills');
      sheet.appendRow([
        data.id || ('art-' + new Date().getTime()),
        new Date().toISOString(),
        data.name || '',
        data.trade || '',
        data.experience || 0,
        data.phone || '',
        data.rate || '',
        data.address || '',
        data.bio || '',
        data.coords ? data.coords[0] : '',
        data.coords ? data.coords[1] : ''
      ]);
      return createJsonResponse({ status: 'success', message: 'Artisan registered successfully' });
    }

    if (action === 'addClientRating') {
      var ratingsSheet = ss.getSheetByName('Client_Ratings');
      ratingsSheet.appendRow([
        new Date().toISOString(),
        data.artisanId || '',
        data.artisanName || '',
        data.client || '',
        data.job || '',
        data.stars || 5,
        data.text || ''
      ]);
      return createJsonResponse({ status: 'success', message: 'Client rating logged successfully' });
    }

    if (action === 'reserveTool') {
      var toolsSheet = ss.getSheetByName('Tool_Reservations');
      toolsSheet.appendRow([
        new Date().toISOString(),
        data.toolId || '',
        data.toolName || '',
        'Reserved'
      ]);
      return createJsonResponse({ status: 'success', message: 'Tool reservation logged successfully' });
    }

    return createJsonResponse({ status: 'error', message: 'Unknown action: ' + action });

  } catch (err) {
    return createJsonResponse({ status: 'error', message: err.toString() });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Handle GET requests (returns current registered artisans and ratings as JSON)
 */
function doGet(e) {
  try {
    setupSpreadsheet();
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var skillsSheet = ss.getSheetByName('Artisans_Skills');
    var data = skillsSheet.getDataRange().getValues();

    var headers = data[0];
    var artisans = [];

    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      artisans.push({
        id: row[0],
        timestamp: row[1],
        name: row[2],
        trade: row[3],
        experience: row[4],
        phone: row[5],
        rate: row[6],
        address: row[7],
        bio: row[8],
        coords: [row[9], row[10]]
      });
    }

    return createJsonResponse({ status: 'success', artisans: artisans });
  } catch (err) {
    return createJsonResponse({ status: 'error', message: err.toString() });
  }
}

function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
