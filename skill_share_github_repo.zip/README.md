# Skill Share — Neighborhood Skill & Equipment Exchange

A clean, responsive community platform for exploring neighborhood blue-collar skills, viewing nearby tradespeople on an interactive MapTiler/MapLibre map, listing your own skills, borrowing community kiosk tools, and managing incoming service & skill-swap requests.

## Files Included for GitHub Pages
- `index.html` — Main multi-page structure (Explore Skills, Nearby Map, List a Skill, Tool Library, My Profile & Requests)
- `style.css` — Aesthetic Warm Alabaster, Botanical Emerald & Terracotta styling (optimized for Mobile, Tablet & Desktop)
- `app.js` — Frontend logic, live search bars (including header search beside profile picture & profile request search), MapTiler integration, client-only ratings, and silent Google Sheets sync
- `Code.gs` — Google Apps Script backend for Google Sheets (paste into Google Sheets > Extensions > Apps Script)

## How to Host on GitHub Pages
1. Create a new repository on [GitHub](https://github.com/new).
2. Upload `index.html`, `style.css`, `app.js`, `Code.gs`, and `README.md` directly to the root of your repository.
3. Go to **Settings** > **Pages** in your GitHub repository.
4. Under **Build and deployment** > **Branch**, select `main` and `/ (root)`, then click **Save**.
5. Your live website will be published at `https://<your-username>.github.io/<repository-name>/`.
