/**
 * Skill Share: Neighborhood Skill & Equipment Exchange
 * User-Centric Frontend Application Logic
 * - Page 1: Explore All Skills (Starting Directory)
 * - Page 2: Interactive Neighborhood Map (MapTiler + Map Sidebar)
 * - Page 3: Dedicated "List a Skill" System
 * - Page 4: Tool & Equipment Library + Condition Log
 * - Page 5: My Profile, Edit Profile & Incoming/Sent Requests Inbox
 * - Silent Google Sheets Backend Sync (No developer clutter in UI)
 */

const CONFIG = {
  // Replace with your MapTiler API Key in code when deploying
  MAPTILER_KEY: 'YOUR_MAPTILER_API_KEY',
  // Replace with your deployed Google Apps Script Web App URL in code
  GOOGLE_SHEET_WEB_APP_URL: 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL',
  DEFAULT_CENTER: [76.8537, 30.6942], // Neighborhood Hub Coordinates
  DEFAULT_ZOOM: 14.5
};

// ============================================================================
// CURRENT LOGGED-IN USER PROFILE & INCOMING/SENT REQUESTS
// ============================================================================
let currentUserProfile = {
  id: 'user-main',
  name: 'Aarav Sharma',
  trade: 'Carpenter',
  rate: '₹400/hr',
  experience: 10,
  phone: '+91 98112 23344',
  address: 'House 18, Oakwood Block B',
  bio: 'Custom furniture repair, door alignment, modular cabinet fixing, and wooden deck maintenance. Carry full Bosch cordless kit.'
};

let incomingRequests = [
  {
    id: 'req-101',
    clientName: 'Ritu Verma',
    clientAddress: 'House 44, Sector 12 (200m away)',
    type: 'Direct Hire (Paid Service)',
    requestedDate: 'Tomorrow, 11:00 AM',
    offer: '₹600 Fixed',
    message: 'Need two bedroom wooden doors planed and a new brass mortise lock fitted.',
    status: 'Pending'
  },
  {
    id: 'req-102',
    clientName: 'Karan Malhotra',
    clientAddress: 'Villa 9, Cedar Lane',
    type: 'Skill Exchange (Swap Skills)',
    requestedDate: 'This Saturday, 4:00 PM',
    offer: 'Swap: 2 hrs Electrical Wiring Check',
    message: 'I am a licensed electrician. Can fix your balcony floodlights in exchange for repairing our dining table leg.',
    status: 'Pending'
  },
  {
    id: 'req-103',
    clientName: 'Meera Krishnan',
    clientAddress: 'Flat 302, Green View Apartments',
    type: 'Direct Hire (Paid Service)',
    requestedDate: 'Oct 28, 10:30 AM',
    offer: '₹400/hr',
    message: 'Modular kitchen drawer channels need replacement.',
    status: 'Accepted'
  }
];

let sentRequests = [
  {
    id: 'sent-201',
    targetName: 'Mateo Rodriguez',
    targetTrade: 'Plumber',
    type: 'Direct Hire (Paid Service)',
    requestedDate: 'Sunday, 9:30 AM',
    offer: '₹450/hr',
    message: 'Overhead water tank float valve replacement.',
    status: 'Accepted'
  }
];

// ============================================================================
// INITIAL SEED DATA: SKILLED NEIGHBORS & COMMUNITY TOOLS
// ============================================================================
let artisansData = [
  {
    id: 'art-1',
    name: 'David Kowalski',
    trade: 'Carpenter',
    experience: 12,
    rate: '₹450/hr',
    phone: '+91 98765 11022',
    address: '14 Elmwood Terrace',
    availability: 'Weekdays & Weekends (8 AM - 8 PM)',
    exchangeMode: 'Yes - Open to Paid Work or Skill Swap',
    specialties: ['Cabinet Hinges', 'Door Framing', 'Custom Shelving'],
    bio: 'Custom framing, cabinet hinge fixes, deck rebuilding, and custom pantry shelving.',
    coords: [76.8515, 30.6960],
    reviews: [
      { client: 'Elena Vance', job: 'Porch Stair Repair', stars: 5, date: '2026-10-18', text: 'Replaced rotted stringers in one afternoon. Solid craftsmanship and cleaned up completely.' },
      { client: 'Tom Becker', job: 'Custom Pantry Shelves', stars: 5, date: '2026-09-04', text: 'Prompt, measured twice, and charge was exactly as estimated.' }
    ]
  },
  {
    id: 'art-2',
    name: 'Mateo Rodriguez',
    trade: 'Plumber',
    experience: 15,
    rate: '₹400/hr',
    phone: '+91 98765 99341',
    address: '28 Maplewood Avenue',
    availability: '24/7 Emergency Calls Available',
    exchangeMode: 'Yes - Open to Paid Work or Skill Swap',
    specialties: ['Leak Detection', 'Geyser Piping', 'Drain Unblocking'],
    bio: 'Residential piping, water heater troubleshooting, drain unblocking, and bathroom fittings.',
    coords: [76.8565, 30.6928],
    reviews: [
      { client: 'Rachel Green', job: 'Emergency Pipe Leak', stars: 5, date: '2026-10-29', text: 'Came over in 20 minutes when our main valve leaked. True neighborhood lifesaver.' },
      { client: 'Sam Patel', job: 'Kitchen Sink Trap Fix', stars: 5, date: '2026-08-14', text: 'Very neat work, brought all spare washers and PVC fittings.' }
    ]
  },
  {
    id: 'art-3',
    name: 'Aisha Al-Mansoor',
    trade: 'Electrician',
    experience: 9,
    rate: '₹500/hr',
    phone: '+91 98765 88710',
    address: '5 Birch Hill Road',
    availability: 'Weekdays & Weekends (8 AM - 8 PM)',
    exchangeMode: 'Paid Bookings Only',
    specialties: ['Inverter Setup', 'MCB Box', 'EV Charger Install'],
    bio: 'EV charger installation, MCB circuit breaker replacement, inverter wiring, and ceiling fan installations.',
    coords: [76.8495, 30.6915],
    reviews: [
      { client: 'Arthur Pendelton', job: 'EV Charger & MCB Upgrade', stars: 5, date: '2026-11-01', text: 'Clean conduit runs through the garage and tested earthing properly.' }
    ]
  },
  {
    id: 'art-4',
    name: 'Liam Chen',
    trade: 'Appliance Repair',
    experience: 7,
    rate: '₹350/hr',
    phone: '+91 98765 33452',
    address: '73 Willow Lane',
    availability: 'Evenings Only (5 PM - 9 PM)',
    exchangeMode: 'Yes - Open to Paid Work or Skill Swap',
    specialties: ['Washing Machines', 'RO Purifiers', 'Microwaves'],
    bio: 'Diagnosis and repair for washing machines, RO water purifiers, refrigerators, and microwave ovens.',
    coords: [76.8580, 30.6972],
    reviews: [
      { client: 'Grace Hopper', job: 'Dryer Heating Element', stars: 5, date: '2026-10-12', text: 'Diagnosed thermal fuse failure immediately, saved us from buying a new machine.' }
    ]
  },
  {
    id: 'art-5',
    name: 'Carlos Mendez',
    trade: 'Gardener & Landscaper',
    experience: 11,
    rate: '₹300/hr',
    phone: '+91 98765 22449',
    address: '104 Cedar Way',
    availability: 'Weekends Only (Sat - Sun)',
    exchangeMode: 'Yes - Open to Paid Work or Skill Swap',
    specialties: ['Hedge Pruning', 'Lawn Aeration', 'Drip Irrigation'],
    bio: 'Seasonal lawn aeration, hedge sculpting, terrace garden drip irrigation setup, and organic composting.',
    coords: [76.8528, 30.6985],
    reviews: [
      { client: 'Karen Diaz', job: 'Terrace Drip Line Setup', stars: 5, date: '2026-09-22', text: 'Knowledgeable about seasonal plants. Our garden looks vibrant.' }
    ]
  },
  {
    id: 'art-6',
    name: 'Rajesh Verma',
    trade: 'Painter',
    experience: 14,
    rate: '₹380/hr',
    phone: '+91 98765 77812',
    address: '61 Pine Crest Colony',
    availability: 'Weekdays & Weekends (8 AM - 8 PM)',
    exchangeMode: 'Yes - Open to Paid Work or Skill Swap',
    specialties: ['Wall Putty', 'Waterproofing', 'Wood Polish'],
    bio: 'Interior texture painting, dampness waterproofing treatment, exterior priming, and furniture melamine polish.',
    coords: [76.8482, 30.6952],
    reviews: [
      { client: 'Vikram Sethi', job: 'Living Room Accent Wall', stars: 5, date: '2026-10-05', text: 'Covered all furniture with drop cloths and finished ahead of schedule.' }
    ]
  }
];

let toolsData = [
  {
    id: 'tool-1',
    name: 'DeWalt 20V Max Hammer Drill & Masonry Bit Kit',
    category: 'Drilling & Fastening',
    lockerKiosk: 'Kiosk A - Locker #04',
    condition: 'Excellent (100% Working)',
    lastBorrower: 'Marcus Vance',
    scheduledWindow: 'Available Now',
    status: 'Available',
    borrowCount: 28
  },
  {
    id: 'tool-2',
    name: 'Little Giant 22ft Telescoping Multi-Ladder',
    category: 'High Reach & Roof',
    lockerKiosk: 'Kiosk B - Locker #01',
    condition: 'Good (Safety Inspected)',
    lastBorrower: 'Priya Nair',
    scheduledWindow: 'Available Now',
    status: 'Available',
    borrowCount: 39
  },
  {
    id: 'tool-3',
    name: 'Bosch Aquatak 135 Bar High-Pressure Washer',
    category: 'Driveway & Patio Cleaning',
    lockerKiosk: 'Kiosk A - Locker #07',
    condition: 'Excellent (100% Working)',
    lastBorrower: 'Daniel Cho',
    scheduledWindow: 'Booked Today, 4 PM - 7 PM',
    status: 'Reserved',
    borrowCount: 51
  },
  {
    id: 'tool-4',
    name: 'Ryobi 40V Cordless Lawn Aerator & trimmer',
    category: 'Garden & Lawn Care',
    lockerKiosk: 'Kiosk C - Locker #02',
    condition: 'Good (Normal Wear)',
    lastBorrower: 'Hannah Abbott',
    scheduledWindow: 'Available Now',
    status: 'Available',
    borrowCount: 19
  }
];

let mapInstance = null;
let mapMarkers = [];
let activeTradeFilter = 'all';

// ============================================================================
// SAFE STORAGE HELPERS
// ============================================================================
function safeGetStorage(key) {
  try { return localStorage.getItem(key); } catch (e) { return null; }
}

function safeSetStorage(key, value) {
  try { localStorage.setItem(key, value); } catch (e) {}
}

// ============================================================================
// APPLICATION INITIALIZATION
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
  loadStoredData();
  renderProfileUI();
  renderArtisans(artisansData);
  renderTools(toolsData);
  renderRequestsInbox();
  updateStats();
  initMap();
  setupEventListeners();

  if (window.lucide) {
    lucide.createIcons();
  }
});

function loadStoredData() {
  const cachedArtisans = safeGetStorage('skillshare-v3-artisans');
  if (cachedArtisans) {
    try { artisansData = JSON.parse(cachedArtisans); } catch (e) {}
  }

  const cachedProfile = safeGetStorage('skillshare-v3-profile');
  if (cachedProfile) {
    try { currentUserProfile = JSON.parse(cachedProfile); } catch (e) {}
  }

  const cachedIncoming = safeGetStorage('skillshare-v3-incoming');
  if (cachedIncoming) {
    try { incomingRequests = JSON.parse(cachedIncoming); } catch (e) {}
  }

  const cachedSent = safeGetStorage('skillshare-v3-sent');
  if (cachedSent) {
    try { sentRequests = JSON.parse(cachedSent); } catch (e) {}
  }
}

function saveLocalData() {
  safeSetStorage('skillshare-v3-artisans', JSON.stringify(artisansData));
  safeSetStorage('skillshare-v3-profile', JSON.stringify(currentUserProfile));
  safeSetStorage('skillshare-v3-incoming', JSON.stringify(incomingRequests));
  safeSetStorage('skillshare-v3-sent', JSON.stringify(sentRequests));
}

// ============================================================================
// MULTI-PAGE NAVIGATION ROUTING
// ============================================================================
window.switchPage = function(pageId) {
  document.querySelectorAll('.page-view').forEach(view => {
    view.classList.remove('active');
  });

  const target = document.getElementById(`page-${pageId}`);
  if (target) {
    target.classList.add('active');
  }

  document.querySelectorAll('.nav-link, .mob-tab').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-page') === pageId);
  });

  if (pageId === 'map' && mapInstance) {
    setTimeout(() => {
      mapInstance.resize();
    }, 80);
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
};

// ============================================================================
// EXPLORE SKILLS DIRECTORY & CATEGORY PILLS
// ============================================================================
window.filterByCategory = function(trade) {
  activeTradeFilter = trade;
  document.querySelectorAll('.cat-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-trade') === trade);
  });

  applyExploreFilters();
};

function applyExploreFilters() {
  const searchInput = document.getElementById('artisan-search-input');
  const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

  const filtered = artisansData.filter(a => {
    const matchesTrade = (activeTradeFilter === 'all') || (a.trade === activeTradeFilter);
    const matchesQuery = !query ||
      a.name.toLowerCase().includes(query) ||
      a.trade.toLowerCase().includes(query) ||
      a.address.toLowerCase().includes(query) ||
      a.bio.toLowerCase().includes(query) ||
      (a.specialties && a.specialties.some(s => s.toLowerCase().includes(query)));
    return matchesTrade && matchesQuery;
  });

  renderArtisans(filtered);
}

function calculateArtisanRating(reviews = []) {
  if (!reviews || reviews.length === 0) {
    return { average: 'New', count: 0, stars: 5 };
  }
  const sum = reviews.reduce((acc, r) => acc + Number(r.stars), 0);
  const avg = (sum / reviews.length).toFixed(1);
  return { average: avg, count: reviews.length, stars: Math.round(avg) };
}

function renderArtisans(artisans) {
  const grid = document.getElementById('artisans-grid');
  if (!grid) return;

  if (artisans.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem; background: var(--bg-surface); border-radius: var(--radius-lg); border: 1px solid var(--border-color);">
        <h3 style="margin-bottom:0.4rem;">No matching skills found</h3>
        <p style="color:var(--text-muted);font-size:0.9rem;">Try clearing your search filter or list a new skill in this category.</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = artisans.map(artisan => {
    const stats = calculateArtisanRating(artisan.reviews);
    const initials = artisan.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    const tradeClass = artisan.trade.toLowerCase().replace(/[^a-z]/g, '');
    const latestReview = artisan.reviews && artisan.reviews.length > 0
      ? artisan.reviews[artisan.reviews.length - 1]
      : null;

    const specs = (artisan.specialties && artisan.specialties.length > 0)
      ? artisan.specialties
      : [artisan.trade, 'Home Visits', 'Verified Neighbor'];

    return `
      <article class="artisan-card" data-id="${artisan.id}">
        <div class="artisan-header">
          <div class="artisan-avatar">${initials}</div>
          <div class="artisan-info">
            <div class="artisan-name-row">
              <h3 class="artisan-name">${artisan.name}</h3>
              <span class="badge ${tradeClass}">${artisan.trade}</span>
            </div>
            <div class="artisan-meta">
              <span><i data-lucide="map-pin" style="width:13px;height:13px;vertical-align:middle;"></i> ${artisan.address}</span>
              <span>&bull;</span>
              <span>${artisan.experience} yrs exp</span>
            </div>
          </div>
        </div>

        <p class="artisan-bio">${artisan.bio}</p>

        <div class="skill-tags-row">
          ${specs.map(tag => `<span class="skill-chip">${tag}</span>`).join('')}
        </div>

        <!-- Client-Only Rating Box -->
        <div class="artisan-rating-section">
          <div class="rating-summary-row">
            <div class="rating-stars-display">
              ${'★'.repeat(stats.count > 0 ? stats.stars : 5)}
              <span class="rating-score">${stats.average}</span>
            </div>
            <span class="rating-count">${stats.count} client review${stats.count === 1 ? '' : 's'}</span>
          </div>

          ${latestReview ? `
            <div class="client-review-quote">
              "${latestReview.text}"
              <div class="client-reviewer-tag">&mdash; Client: ${latestReview.client} (${latestReview.job})</div>
            </div>
          ` : `
            <div style="font-size:0.76rem;color:var(--text-muted);font-style:italic;">
              New listing &mdash; Only clients who hire ${artisan.name.split(' ')[0]} can submit a rating.
            </div>
          `}
        </div>

        <div class="artisan-card-actions">
          <span class="artisan-rate-tag">${artisan.rate}</span>
          <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
            <button type="button" class="btn btn-outline btn-sm" onclick="focusArtisanOnMap('${artisan.id}')" title="View on Map">
              <i data-lucide="map-pin"></i>
              <span>Map</span>
            </button>
            <button type="button" class="btn btn-outline btn-sm" onclick="openRatingModal('${artisan.id}')">
              <i data-lucide="star"></i>
              <span>Rate</span>
            </button>
            <button type="button" class="btn btn-primary btn-sm" onclick="openRequestModal('${artisan.id}')">
              <i data-lucide="calendar-plus"></i>
              <span>Request</span>
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');

  if (window.lucide) {
    lucide.createIcons();
  }
}

// ============================================================================
// MAPTILER NEIGHBORHOOD MAP & SIDEBAR
// ============================================================================
function initMap() {
  const mapContainer = document.getElementById('maptiler-map');
  if (!mapContainer) return;

  const hasValidKey = CONFIG.MAPTILER_KEY && CONFIG.MAPTILER_KEY !== 'YOUR_MAPTILER_API_KEY';

  const styleSource = hasValidKey
    ? `https://api.maptiler.com/maps/streets-v2/style.json?key=${CONFIG.MAPTILER_KEY}`
    : {
        version: 8,
        sources: {
          'osm-tiles': {
            type: 'raster',
            tiles: [
              'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
              'https://b.tile.openstreetmap.org/{z}/{x}/{y}.png'
            ],
            tileSize: 256,
            attribution: '&copy; OpenStreetMap Contributors'
          }
        },
        layers: [
          {
            id: 'osm-layer',
            type: 'raster',
            source: 'osm-tiles',
            minzoom: 0,
            maxzoom: 19
          }
        ]
      };

  try {
    mapInstance = new maplibregl.Map({
      container: 'maptiler-map',
      style: styleSource,
      center: CONFIG.DEFAULT_CENTER,
      zoom: CONFIG.DEFAULT_ZOOM
    });

    mapInstance.addControl(new maplibregl.NavigationControl({ showCompass: true }), 'top-right');

    mapInstance.on('load', () => {
      refreshMapMarkers(artisansData);
    });
  } catch (err) {
    console.error('Map initialization error:', err);
  }

  renderMapSidebar(artisansData);
}

function refreshMapMarkers(artisans) {
  renderMapSidebar(artisans);
  if (!mapInstance) return;

  mapMarkers.forEach(m => m.remove());
  mapMarkers = [];

  artisans.forEach(artisan => {
    const el = document.createElement('div');
    el.className = 'custom-map-marker';
    el.title = `${artisan.name} (${artisan.trade})`;
    el.innerHTML = `<i data-lucide="${getTradeIcon(artisan.trade)}"></i>`;

    const stats = calculateArtisanRating(artisan.reviews);
    const popupHtml = `
      <div style="font-family:var(--font-sans);padding:2px;">
        <h4 style="font-size:0.95rem;margin-bottom:2px;">${artisan.name}</h4>
        <span class="badge ${artisan.trade.toLowerCase()}">${artisan.trade}</span>
        <div style="font-size:0.78rem;color:var(--text-body);margin:6px 0;">
          <strong>${artisan.rate}</strong> &bull; ${artisan.address}
        </div>
        <div style="font-size:0.78rem;color:var(--accent-amber);margin-bottom:8px;">
          ★ <strong>${stats.average}</strong> (${stats.count} client reviews)
        </div>
        <div style="display:flex;gap:4px;">
          <button type="button" class="btn btn-primary btn-sm" onclick="openRequestModal('${artisan.id}')" style="flex:1;">Hire / Swap</button>
          <button type="button" class="btn btn-outline btn-sm" onclick="openRatingModal('${artisan.id}')">Rate</button>
        </div>
      </div>
    `;

    const popup = new maplibregl.Popup({ offset: 24 }).setHTML(popupHtml);
    const marker = new maplibregl.Marker({ element: el })
      .setLngLat(artisan.coords)
      .setPopup(popup)
      .addTo(mapInstance);

    mapMarkers.push(marker);
  });

  if (window.lucide) {
    lucide.createIcons();
  }
}

function renderMapSidebar(artisans) {
  const listEl = document.getElementById('map-sidebar-list');
  const countEl = document.getElementById('map-list-count');
  if (countEl) countEl.textContent = artisans.length;
  if (!listEl) return;

  listEl.innerHTML = artisans.map(a => {
    const stats = calculateArtisanRating(a.reviews);
    return `
      <div class="map-mini-card" onclick="flyToNeighbor('${a.id}')">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <strong style="font-size:0.9rem;">${a.name}</strong>
          <span class="badge" style="font-size:0.68rem;">${a.trade}</span>
        </div>
        <div style="font-size:0.78rem;color:var(--text-muted);margin-top:0.2rem;">${a.address}</div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:0.45rem;font-size:0.78rem;">
          <span style="font-weight:700;color:var(--accent-primary);">${a.rate}</span>
          <span style="color:var(--accent-amber);font-weight:700;">★ ${stats.average} (${stats.count})</span>
        </div>
      </div>
    `;
  }).join('');
}

window.flyToNeighbor = function(artisanId) {
  const artisan = artisansData.find(a => a.id === artisanId);
  if (!artisan || !mapInstance) return;
  mapInstance.flyTo({ center: artisan.coords, zoom: 16.2 });
};

window.focusArtisanOnMap = function(artisanId) {
  const artisan = artisansData.find(a => a.id === artisanId);
  if (!artisan) return;
  switchPage('map');
  setTimeout(() => {
    if (mapInstance) {
      mapInstance.resize();
      mapInstance.flyTo({ center: artisan.coords, zoom: 16.2 });
    }
  }, 120);
};

function getTradeIcon(trade) {
  switch (trade) {
    case 'Plumber': return 'droplet';
    case 'Carpenter': return 'hammer';
    case 'Electrician': return 'zap';
    case 'Appliance Repair': return 'settings';
    case 'Gardener & Landscaper': return 'sprout';
    case 'Painter': return 'paint-brush';
    default: return 'wrench';
  }
}

// ============================================================================
// MY PROFILE, EDIT PROFILE & INCOMING REQUESTS INBOX
// ============================================================================
function renderProfileUI() {
  const initials = currentUserProfile.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();

  const headerAvatar = document.getElementById('header-user-avatar');
  const headerName = document.getElementById('header-user-name');
  const headerTrade = document.getElementById('header-user-trade');
  if (headerAvatar) headerAvatar.textContent = initials;
  if (headerName) headerName.textContent = currentUserProfile.name;
  if (headerTrade) headerTrade.textContent = currentUserProfile.trade;
  const barAvatar = document.getElementById('bar-user-avatar');
  const barName = document.getElementById('bar-user-name');
  if (barAvatar) barAvatar.textContent = initials;
  if (barName) barName.textContent = currentUserProfile.name;

  const profAvatar = document.getElementById('prof-avatar-display');
  const profTrade = document.getElementById('prof-trade-display');
  const profName = document.getElementById('prof-name-display');
  const profAddress = document.getElementById('prof-address-display');
  const profBio = document.getElementById('prof-bio-display');
  const profRate = document.getElementById('prof-rate-display');
  const profExp = document.getElementById('prof-exp-display');

  if (profAvatar) profAvatar.textContent = initials;
  if (profTrade) profTrade.textContent = currentUserProfile.trade;
  if (profName) profName.textContent = currentUserProfile.name;
  if (profAddress) profAddress.textContent = currentUserProfile.address;
  if (profBio) profBio.textContent = currentUserProfile.bio;
  if (profRate) profRate.textContent = currentUserProfile.rate;
  if (profExp) profExp.textContent = `${currentUserProfile.experience} Yrs`;
}

window.toggleEditProfile = function() {
  const panel = document.getElementById('edit-profile-panel');
  if (!panel) return;
  const isHidden = panel.style.display === 'none';
  panel.style.display = isHidden ? 'block' : 'none';
};

function handleProfileSave(e) {
  e.preventDefault();
  currentUserProfile.name = document.getElementById('edit-prof-name').value.trim();
  currentUserProfile.trade = document.getElementById('edit-prof-trade').value;
  currentUserProfile.rate = document.getElementById('edit-prof-rate').value.trim();
  currentUserProfile.experience = parseInt(document.getElementById('edit-prof-exp').value) || 5;
  currentUserProfile.phone = document.getElementById('edit-prof-phone').value.trim();
  currentUserProfile.address = document.getElementById('edit-prof-address').value.trim();
  currentUserProfile.bio = document.getElementById('edit-prof-bio').value.trim();

  saveLocalData();
  renderProfileUI();
  document.getElementById('edit-profile-panel').style.display = 'none';
  showToast('Your profile and skill details have been updated!', 'success');

  syncToGoogleSheets({
    action: 'updateUserProfile',
    data: currentUserProfile
  });
}

window.switchRequestTab = function(tab) {
  const incList = document.getElementById('incoming-requests-list');
  const sentList = document.getElementById('sent-requests-list');

  document.querySelectorAll('.tab-pill').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-reqtab') === tab);
  });

  if (tab === 'incoming') {
    if (incList) incList.style.display = 'flex';
    if (sentList) sentList.style.display = 'none';
  } else {
    if (incList) incList.style.display = 'none';
    if (sentList) sentList.style.display = 'flex';
  }
};

window.jumpToExploreSearch = function() {
  const profSearch = document.getElementById('profile-request-search');
  const mainSearch = document.getElementById('artisan-search-input');
  const headerSearch = document.getElementById('header-search-input');
  const q = profSearch ? profSearch.value.trim() : '';
  if (mainSearch) mainSearch.value = q;
  if (headerSearch) headerSearch.value = q;
  switchPage('home');
  applyExploreFilters();
};

function renderRequestsInbox() {
  const incContainer = document.getElementById('incoming-requests-list');
  const sentContainer = document.getElementById('sent-requests-list');
  const profSearchEl = document.getElementById('profile-request-search');
  const reqQuery = profSearchEl ? profSearchEl.value.toLowerCase().trim() : '';
  const pendingCount = incomingRequests.filter(r => r.status === 'Pending').length;

  const navBadge = document.getElementById('nav-req-badge');
  const mobBadge = document.getElementById('mob-req-badge');
  const incCountNum = document.getElementById('incoming-count-num');
  const sentCountNum = document.getElementById('sent-count-num');

  if (navBadge) navBadge.textContent = pendingCount;
  if (mobBadge) mobBadge.textContent = pendingCount;
  if (incCountNum) incCountNum.textContent = incomingRequests.length;
  if (sentCountNum) sentCountNum.textContent = sentRequests.length;

  const filteredIncoming = incomingRequests.filter(req =>
    !reqQuery ||
    req.clientName.toLowerCase().includes(reqQuery) ||
    req.message.toLowerCase().includes(reqQuery) ||
    req.type.toLowerCase().includes(reqQuery) ||
    req.clientAddress.toLowerCase().includes(reqQuery)
  );

  if (incContainer) {
    incContainer.innerHTML = filteredIncoming.map(req => {
      const statusClass = req.status.toLowerCase();
      return `
        <div class="request-item-card">
          <div class="req-top-bar">
            <div class="req-client-info">
              <div class="artisan-avatar-sm" style="width:36px;height:36px;font-size:0.8rem;">
                ${req.clientName.split(' ').map(n=>n[0]).join('')}
              </div>
              <div>
                <strong style="font-size:0.95rem;">${req.clientName}</strong>
                <div style="font-size:0.76rem;color:var(--text-muted);">${req.clientAddress}</div>
              </div>
            </div>
            <span class="req-status-badge ${statusClass}">${req.status}</span>
          </div>

          <p style="font-size:0.88rem;color:var(--text-main);">${req.message}</p>

          <div class="req-meta-grid">
            <span><strong>Type:</strong> ${req.type}</span>
            <span><strong>When:</strong> ${req.requestedDate}</span>
            <span><strong>Offer:</strong> <span style="color:var(--accent-primary);font-weight:700;">${req.offer}</span></span>
          </div>

          ${req.status === 'Pending' ? `
            <div class="req-actions">
              <button type="button" class="btn btn-outline btn-sm" onclick="updateRequestStatus('${req.id}', 'Declined')">
                Decline
              </button>
              <button type="button" class="btn btn-primary btn-sm" onclick="updateRequestStatus('${req.id}', 'Accepted')">
                <i data-lucide="check"></i>
                <span>Accept Request</span>
              </button>
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
  }

  const filteredSent = sentRequests.filter(req =>
    !reqQuery ||
    req.targetName.toLowerCase().includes(reqQuery) ||
    req.targetTrade.toLowerCase().includes(reqQuery) ||
    req.message.toLowerCase().includes(reqQuery)
  );

  if (sentContainer) {
    sentContainer.innerHTML = filteredSent.map(req => {
      const statusClass = req.status.toLowerCase();
      return `
        <div class="request-item-card">
          <div class="req-top-bar">
            <div>
              <strong style="font-size:0.95rem;">To: ${req.targetName} (${req.targetTrade})</strong>
              <div style="font-size:0.76rem;color:var(--text-muted);">${req.type}</div>
            </div>
            <span class="req-status-badge ${statusClass}">${req.status}</span>
          </div>
          <p style="font-size:0.88rem;color:var(--text-main);">${req.message}</p>
          <div class="req-meta-grid">
            <span><strong>Requested Slot:</strong> ${req.requestedDate}</span>
            <span><strong>Offer:</strong> ${req.offer}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  if (window.lucide) {
    lucide.createIcons();
  }
}

window.updateRequestStatus = function(reqId, newStatus) {
  const item = incomingRequests.find(r => r.id === reqId);
  if (!item) return;

  item.status = newStatus;
  saveLocalData();
  renderRequestsInbox();
  showToast(`Request from ${item.clientName} marked as ${newStatus}.`, 'success');

  syncToGoogleSheets({
    action: 'updateServiceRequest',
    data: { requestId: reqId, clientName: item.clientName, status: newStatus }
  });
};

// ============================================================================
// SEND HIRE / SKILL EXCHANGE REQUEST TO A NEIGHBOR
// ============================================================================
window.openRequestModal = function(artisanId) {
  const artisan = artisansData.find(a => a.id === artisanId);
  if (!artisan) return;

  document.getElementById('req-target-id').value = artisan.id;
  document.getElementById('req-target-name').textContent = artisan.name;
  document.getElementById('req-target-trade').textContent = artisan.trade;
  document.getElementById('req-target-avatar').textContent = artisan.name.split(' ').map(n=>n[0]).join('').substring(0,2);
  document.getElementById('req-date').value = '';
  document.getElementById('req-offer').value = artisan.rate;
  document.getElementById('req-message').value = '';

  document.getElementById('request-modal').classList.add('active');
};

function handleSendRequestSubmit(e) {
  e.preventDefault();
  const targetId = document.getElementById('req-target-id').value;
  const artisan = artisansData.find(a => a.id === targetId);
  if (!artisan) return;

  const newSent = {
    id: 'sent-' + Date.now(),
    targetName: artisan.name,
    targetTrade: artisan.trade,
    type: document.getElementById('req-type').value,
    requestedDate: document.getElementById('req-date').value.trim(),
    offer: document.getElementById('req-offer').value.trim(),
    message: document.getElementById('req-message').value.trim(),
    status: 'Pending'
  };

  sentRequests.unshift(newSent);
  saveLocalData();
  renderRequestsInbox();

  document.getElementById('request-modal').classList.remove('active');
  showToast(`Request sent to ${artisan.name}! You can track it in My Profile > Sent by Me.`, 'success');

  syncToGoogleSheets({
    action: 'createServiceRequest',
    data: newSent
  });
}

// ============================================================================
// LIST A SKILL (FULL PAGE REGISTRATION)
// ============================================================================
function handleSkillRegister(e) {
  e.preventDefault();

  const name = document.getElementById('reg-name').value.trim();
  const trade = document.getElementById('reg-skill').value;
  const experience = parseInt(document.getElementById('reg-experience').value) || 1;
  const phone = document.getElementById('reg-phone').value.trim();
  const rate = document.getElementById('reg-rate').value.trim();
  const availability = document.getElementById('reg-availability').value;
  const address = document.getElementById('reg-address').value.trim();
  const exchangeMode = document.getElementById('reg-exchange').value;
  const rawSpecs = document.getElementById('reg-specialties').value.trim();
  const bio = document.getElementById('reg-bio').value.trim();

  const specialties = rawSpecs
    ? rawSpecs.split(',').map(s => s.trim()).filter(Boolean)
    : [trade, 'Verified Neighbor'];

  const coords = [
    CONFIG.DEFAULT_CENTER[0] + (Math.random() - 0.5) * 0.012,
    CONFIG.DEFAULT_CENTER[1] + (Math.random() - 0.5) * 0.010
  ];

  const newArtisan = {
    id: 'art-' + Date.now(),
    name,
    trade,
    experience,
    phone,
    rate,
    availability,
    address,
    exchangeMode,
    specialties,
    bio,
    coords,
    reviews: [] // Starts with 0 reviews; only hiring clients can rate
  };

  artisansData.unshift(newArtisan);
  saveLocalData();
  renderArtisans(artisansData);
  refreshMapMarkers(artisansData);
  updateStats();

  document.getElementById('skill-register-form').reset();
  showToast(`${name} (${trade}) is now listed in the directory and pinned on the neighborhood map!`, 'success');

  syncToGoogleSheets({
    action: 'registerArtisan',
    data: newArtisan
  });

  switchPage('home');
}

// ============================================================================
// CLIENT RATING SUBMISSION
// ============================================================================
window.openRatingModal = function(artisanId) {
  const artisan = artisansData.find(a => a.id === artisanId);
  if (!artisan) return;

  document.getElementById('rating-artisan-id').value = artisan.id;
  document.getElementById('rating-artisan-name').textContent = artisan.name;
  document.getElementById('rating-artisan-skill').textContent = artisan.trade;
  document.getElementById('rating-artisan-avatar').textContent = artisan.name.split(' ').map(n=>n[0]).join('').substring(0,2);
  
  document.getElementById('reviewer-name').value = '';
  document.getElementById('job-type').value = '';
  document.getElementById('review-feedback').value = '';
  document.getElementById('rating-stars').value = '5';

  document.querySelectorAll('.picker-star').forEach(s => s.classList.add('selected'));
  document.getElementById('rating-modal').classList.add('active');
};

function handleClientRatingSubmit(e) {
  e.preventDefault();

  const artisanId = document.getElementById('rating-artisan-id').value;
  const stars = parseInt(document.getElementById('rating-stars').value) || 5;
  const client = document.getElementById('reviewer-name').value.trim();
  const job = document.getElementById('job-type').value.trim();
  const text = document.getElementById('review-feedback').value.trim();

  const artisan = artisansData.find(a => a.id === artisanId);
  if (!artisan) return;

  const newReview = {
    client,
    job,
    stars,
    date: new Date().toISOString().split('T')[0],
    text
  };

  if (!artisan.reviews) artisan.reviews = [];
  artisan.reviews.push(newReview);

  saveLocalData();
  applyExploreFilters();
  refreshMapMarkers(artisansData);
  updateStats();

  document.getElementById('rating-modal').classList.remove('active');
  showToast(`Thank you, ${client}! Your client review for ${artisan.name} has been saved.`, 'success');

  syncToGoogleSheets({
    action: 'addClientRating',
    data: { artisanId, artisanName: artisan.name, ...newReview }
  });
}

// ============================================================================
// TOOL LIBRARY & SCHEDULE LOG
// ============================================================================
function renderTools(tools) {
  const container = document.getElementById('tools-grid');
  const ledgerBody = document.getElementById('condition-log-tbody');

  if (container) {
    container.innerHTML = tools.map(tool => {
      const isAvail = tool.status === 'Available';
      return `
        <div class="tool-card">
          <div class="tool-header">
            <span class="badge">${tool.category}</span>
            <span class="tool-status-badge ${isAvail ? 'available' : 'reserved'}">
              ${tool.status}
            </span>
          </div>
          
          <h3 class="tool-title">${tool.name}</h3>

          <div class="tool-details">
            <div class="tool-detail-row">
              <span>Kiosk Locker:</span>
              <strong>${tool.lockerKiosk}</strong>
            </div>
            <div class="tool-detail-row">
              <span>Condition:</span>
              <strong>${tool.condition}</strong>
            </div>
            <div class="tool-detail-row">
              <span>Schedule Status:</span>
              <span>${tool.scheduledWindow}</span>
            </div>
          </div>

          <button type="button" class="btn ${isAvail ? 'btn-primary' : 'btn-outline'} btn-sm" 
            onclick="openToolScheduleModal('${tool.id}')" 
            style="width: 100%; margin-top: 0.4rem;">
            <i data-lucide="${isAvail ? 'key' : 'rotate-ccw'}"></i>
            <span>${isAvail ? 'Reserve & Get Kiosk PIN' : 'Return Tool to Kiosk'}</span>
          </button>
        </div>
      `;
    }).join('');
  }

  if (ledgerBody) {
    ledgerBody.innerHTML = tools.map(tool => {
      const isAvail = tool.status === 'Available';
      return `
        <tr>
          <td><strong>${tool.name}</strong></td>
          <td>${tool.lockerKiosk}</td>
          <td>${tool.lastBorrower}</td>
          <td>${tool.scheduledWindow}</td>
          <td><span class="badge">${tool.condition}</span></td>
          <td>
            <button type="button" class="btn btn-outline btn-sm" onclick="openToolScheduleModal('${tool.id}')">
              ${isAvail ? 'Reserve' : 'Return'}
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  if (window.lucide) {
    lucide.createIcons();
  }
}

window.openToolScheduleModal = function(toolId) {
  const tool = toolsData.find(t => t.id === toolId);
  if (!tool) return;

  if (tool.status === 'Reserved') {
    tool.status = 'Available';
    tool.scheduledWindow = 'Available Now';
    renderTools(toolsData);
    showToast(`${tool.name} returned to ${tool.lockerKiosk}.`, 'success');
    syncToGoogleSheets({ action: 'returnTool', data: { toolId: tool.id, toolName: tool.name } });
    return;
  }

  document.getElementById('schedule-tool-id').value = tool.id;
  document.getElementById('schedule-tool-name').textContent = tool.name;
  document.getElementById('schedule-tool-kiosk').textContent = tool.lockerKiosk;
  document.getElementById('borrow-date').value = '';
  document.getElementById('tool-modal').classList.add('active');
};

function handleToolScheduleSubmit(e) {
  e.preventDefault();
  const toolId = document.getElementById('schedule-tool-id').value;
  const borrower = document.getElementById('borrower-name').value.trim();
  const slot = document.getElementById('borrow-date').value.trim();
  const cond = document.getElementById('borrow-condition').value;

  const tool = toolsData.find(t => t.id === toolId);
  if (!tool) return;

  tool.status = 'Reserved';
  tool.lastBorrower = borrower;
  tool.scheduledWindow = slot;
  tool.condition = cond;
  tool.borrowCount += 1;

  renderTools(toolsData);
  document.getElementById('tool-modal').classList.remove('active');

  const pin = Math.floor(1000 + Math.random() * 9000);
  showToast(`Booked! Use Locker PIN #${pin} at ${tool.lockerKiosk}.`, 'success');

  syncToGoogleSheets({
    action: 'reserveTool',
    data: { toolId: tool.id, toolName: tool.name, borrower, slot, condition: cond }
  });
}

function updateStats() {
  const aEl = document.getElementById('stat-artisans-count');
  const tEl = document.getElementById('stat-tools-count');
  const rEl = document.getElementById('stat-reviews-count');

  if (aEl) aEl.textContent = artisansData.length;
  if (tEl) tEl.textContent = toolsData.length;
  if (rEl) {
    const totalRev = artisansData.reduce((acc, a) => acc + (a.reviews ? a.reviews.length : 0), 0);
    rEl.textContent = totalRev;
  }
}

// ============================================================================
// EVENT LISTENERS & STAR PICKER
// ============================================================================
function setupEventListeners() {
  const regForm = document.getElementById('skill-register-form');
  if (regForm) regForm.addEventListener('submit', handleSkillRegister);

  const editProfForm = document.getElementById('edit-profile-form');
  if (editProfForm) editProfForm.addEventListener('submit', handleProfileSave);

  const sendReqForm = document.getElementById('send-request-form');
  if (sendReqForm) sendReqForm.addEventListener('submit', handleSendRequestSubmit);

  const closeReqBtn = document.getElementById('close-request-modal-btn');
  const cancelReqBtn = document.getElementById('cancel-request-modal-btn');
  const reqModal = document.getElementById('request-modal');
  if (closeReqBtn) closeReqBtn.addEventListener('click', () => reqModal.classList.remove('active'));
  if (cancelReqBtn) cancelReqBtn.addEventListener('click', () => reqModal.classList.remove('active'));

  const closeRatingBtn = document.getElementById('close-rating-modal-btn');
  const cancelRatingBtn = document.getElementById('cancel-rating-modal-btn');
  const ratingModal = document.getElementById('rating-modal');
  if (closeRatingBtn) closeRatingBtn.addEventListener('click', () => ratingModal.classList.remove('active'));
  if (cancelRatingBtn) cancelRatingBtn.addEventListener('click', () => ratingModal.classList.remove('active'));

  const ratingForm = document.getElementById('client-rating-form');
  if (ratingForm) ratingForm.addEventListener('submit', handleClientRatingSubmit);

  const closeToolBtn = document.getElementById('close-tool-modal-btn');
  const cancelToolBtn = document.getElementById('cancel-tool-modal-btn');
  const toolModal = document.getElementById('tool-modal');
  if (closeToolBtn) closeToolBtn.addEventListener('click', () => toolModal.classList.remove('active'));
  if (cancelToolBtn) cancelToolBtn.addEventListener('click', () => toolModal.classList.remove('active'));

  const toolForm = document.getElementById('tool-schedule-form');
  if (toolForm) toolForm.addEventListener('submit', handleToolScheduleSubmit);

  const searchInput = document.getElementById('artisan-search-input');
  const headerSearchInput = document.getElementById('header-search-input');
  const profileReqSearch = document.getElementById('profile-request-search');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      if (headerSearchInput) headerSearchInput.value = e.target.value;
      applyExploreFilters();
    });
  }

  if (headerSearchInput) {
    headerSearchInput.addEventListener('input', (e) => {
      const val = e.target.value;
      if (searchInput) searchInput.value = val;
      const homeView = document.getElementById('page-home');
      if (homeView && !homeView.classList.contains('active') && val.trim().length > 0) {
        switchPage('home');
      }
      applyExploreFilters();
    });
  }

  if (profileReqSearch) {
    profileReqSearch.addEventListener('input', () => {
      renderRequestsInbox();
    });
  }

  const tradeFilter = document.getElementById('trade-filter');
  if (tradeFilter) {
    tradeFilter.addEventListener('change', (e) => {
      const sel = e.target.value;
      const filtered = sel === 'all' ? artisansData : artisansData.filter(a => a.trade === sel);
      refreshMapMarkers(filtered);
    });
  }

  const recenterBtn = document.getElementById('recenter-map-btn');
  if (recenterBtn) {
    recenterBtn.addEventListener('click', () => {
      if (mapInstance) {
        mapInstance.flyTo({ center: CONFIG.DEFAULT_CENTER, zoom: CONFIG.DEFAULT_ZOOM });
      }
    });
  }

  setupStarPicker();
}

function setupStarPicker() {
  const stars = document.querySelectorAll('.picker-star');
  const ratingInput = document.getElementById('rating-stars');

  stars.forEach(star => {
    star.addEventListener('mouseenter', () => {
      highlightStars(parseInt(star.getAttribute('data-rating')));
    });
    star.addEventListener('mouseleave', () => {
      highlightStars(parseInt(ratingInput.value || '5'));
    });
    star.addEventListener('click', () => {
      const val = parseInt(star.getAttribute('data-rating'));
      ratingInput.value = val;
      highlightStars(val);
    });
  });

  function highlightStars(val) {
    stars.forEach(s => {
      s.classList.toggle('selected', parseInt(s.getAttribute('data-rating')) <= val);
    });
  }
  highlightStars(5);
}

// ============================================================================
// SILENT GOOGLE SHEETS BACKEND SYNC (NO DEVELOPER UI CLUTTER)
// ============================================================================
async function syncToGoogleSheets(payload) {
  const url = CONFIG.GOOGLE_SHEET_WEB_APP_URL;
  if (!url || url === 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL') return;

  try {
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } catch (e) {}
}

function showToast(message) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<i data-lucide="check-circle" style="width:18px;height:18px;color:var(--accent-primary);"></i><span>${message}</span>`;
  container.appendChild(toast);
  if (window.lucide) lucide.createIcons();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = '0.25s ease';
    setTimeout(() => toast.remove(), 250);
  }, 3800);
}
